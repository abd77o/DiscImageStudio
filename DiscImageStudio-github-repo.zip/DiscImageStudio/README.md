# DiscImageStudio

Burn an image onto the **data side** of a CD-R: the picture is made of the disc's own pit pattern,
not a label. C++11, no runtime dependencies, one static `.exe`, built for Windows 7 (32/64-bit) and weak PCs
(Dear ImGui + Direct3D 9, ~12 MB RAM for a whole-disc dither).

> **Experimental.** Tested only against a mock drive so far. Read [docs/HARDWARE_NOTES.md](docs/HARDWARE_NOTES.md)
> before burning, and start with a CD-RW. Use at your own risk.

## How it works
1. **Streaming polar dithering** - the image is sampled along the disc's spiral track and error-diffused
   (Floyd-Steinberg or Jarvis-Judice-Ninke) along the track and across revolutions. Memory stays under a megabyte
   of error buffer regardless of image size.
2. **Sector composer** - tones become byte patterns in raw 2352-byte sectors (Audio layout by default; an
   ECMA-130 scrambler for a Mode-1 layout is included).
3. **SPTI burner** - SEND CUE SHEET + WRITE(10) in raw Disc-At-Once mode, with a buffer monitor that polls
   READ BUFFER CAPACITY and adapts.
4. **Calibration** - a visual ladder of candidate bytes lets you pick the lightest and darkest pattern for your
   drive and media; the result is stored in `config.ini`.

## Build (Windows)
Requirements: Visual Studio 2017 (with *Windows XP support for C++* for `v141_xp`), CMake, git.

    scripts\fetch_deps.bat      :: downloads Dear ImGui and stb_image into third_party\
    build_vs2017.bat            :: -> build\Release\DiscImageStudio.exe  (32-bit, /MT, runs on Win7 32 and 64)

CI (GitHub Actions) builds with the newer VS2019 toolset and runs the mock-drive tests.

## Tests (any OS, no hardware)
    cmake -S . -B build && cmake --build build
    ./build/test_burn_logic && ./build/test_gui_logic

## Use
1. Run as Administrator. Pick the burner and a speed (lower is safer on slow PCs).
2. **Calibration tab:** burn the ladder on a spare CD-R, choose the lightest/darkest ring, save.
3. **Image tab:** choose a PNG/JPG/BMP, run a *Test write*, then untick it and burn.

## Layout
    src/core    geometry, image loading (BMP stream, PNG/JPG via stb), polar dither engine, config
    src/burn    scrambler, sector composer, MMC commands, cue sheet, buffer monitor, DAO writer, SPTI device
    src/calib   calibration sources
    src/gui     burn worker thread, ImGui app, Win32/D3D9 host
    tests       mock-drive tests
    scripts     dependency fetchers

## License
MIT (see LICENSE - put your name in it). Third-party: Dear ImGui (MIT), stb_image (public domain / MIT).
